
/* 
 * File:   Helloworld.cpp
 * Author: Andrew Nicoletti
 * Created on June 24, 2016, 8:50 PM
 * Purpose: hello world
 */
 
#include <iostream>     // System Library

using namespace std;    // Standard I/O Namespace

// User Libraries 

// Global Constants

// Functions Prototypes 

// Exe begins here

int main(int argc, char** argv) {
   
    // Declare Variables
  
    
    // Input Data
    
    // Process Data
   
    // Output Data
    cout<<"Hello World"<<endl;
    
    return 0;
}

